<?php
require_once 'db.php';
$pdo = getConnection();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = $_POST;
    $columns = array_keys($data);
    $placeholders = array_map(function($col) { return ':' . $col; }, $columns);
    $sql = "INSERT INTO utilisateur (" . implode(', ', $columns) . ") VALUES (" . implode(', ', $placeholders) . ")";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($data);
    echo "<p>Enregistrement réussi dans la table utilisateur !</p>";
}
?>

<?php
require_once 'db.php'; // ajuster le chemin si nécessaire
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Formulaireinscription</title>
</head>
<body>

<h1>Formulaireinscription</h1>

<form action="traiter_les_donnees_envoyees.php" method="post">
<div class="container-center">
<div class="border border-secondary rounded" style="padding: 30px 50px;">
<h2 class="text-center text-primary mb-3">Inscription</h2>
<div class="form-group">
<label for="lc">Nom</label>
<input class="form-control" id="lc" name="hc" type="text"/><br/>
<label for="forename">Prénom</label>
<input class="form-control" id="forename" name="hn" type="text"/><br/>
<label for="email">Adresse e-mail</label>
<input class="form-control" id="email" name="email" placeholder="exemple@domaine.com" required="" type="email">
<label class="mt-3" for="password">Mot de passe</label>
<input class="form-control" id="password" name="password" placeholder="Entrez votre mot de passe" required="" type="password">
<label class="mt-3" for="phone">Téléphone</label>
<input class="form-control" id="phone" name="phone" pattern="[0-9]{12}" placeholder="0123456789" required="" type="tel"/>
</input></input></div>
<fieldset class="border-top border-bottom border-secondary mt-3" style="padding: 10px;">
<legend class="text-center text-primary">Vous êtes?</legend>
<div class="d-flex flex-column m-3">
<input checked="" class="btn-check" id="ja" name="r" type="radio" value="yes"/>
<label class="btn btn-outline-primary" for="ja">Homme</label>
<input class="btn-check" id="nee" name="r" type="radio" value="no"/>
<label class="btn btn-outline-primary" for="nee">Femme</label>
<input class="btn-check" id="other" name="r" type="radio" value="maybe"/>
<label class="btn btn-outline-primary" for="other">Autre</label>
</div>
</fieldset>
<div class="d-flex flex-row" style="margin: 15% 0 5% 0;">
<a class="btn btn-outline-primary w-75" href="choix.html">S'inscrire</a>
<a class="btn btn-outline-secondary" href="pagedaccueil.html">Annuler</a>
</div>
</div>
</div>
</form>

</body>
</html>
