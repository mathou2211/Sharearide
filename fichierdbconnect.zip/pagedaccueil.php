<?php
require_once 'db.php';
$pdo = getConnection();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = $_POST;
    $columns = array_keys($data);
    $placeholders = array_map(function($col) { return ':' . $col; }, $columns);
    $sql = "INSERT INTO utilisateur (" . implode(', ', $columns) . ") VALUES (" . implode(', ', $placeholders) . ")";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($data);
    echo "<p>Enregistrement réussi dans la table utilisateur !</p>";
}
?>

<?php
require_once 'db.php'; // ajuster le chemin si nécessaire
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Pagedaccueil</title>
</head>
<body>

<h1>Pagedaccueil</h1>

<form @submit.prevent="login">
<a class="btn btn-outline-primary w-100 mr-2 btn-size-medium" href="seconnecter.html">Se connecter</a>
</form>

<form @submit.prevent="login">
<a class="btn btn-outline-secondary w-100 mf-2 btn-size-medium" href="formulaireinscription.html">S'inscrire</a>
<p class="form-text">Pas de compte ? Créer en un !</p>
</form>

</body>
</html>
