<?php
require_once 'db.php';
$pdo = getConnection();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = $_POST;
    $columns = array_keys($data);
    $placeholders = array_map(function($col) { return ':' . $col; }, $columns);
    $sql = "INSERT INTO reservation (" . implode(', ', $columns) . ") VALUES (" . implode(', ', $placeholders) . ")";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($data);
    echo "<p>Enregistrement réussi dans la table reservation !</p>";
}
?>

<?php
require_once 'db.php'; // ajuster le chemin si nécessaire
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Reservation</title>
</head>
<body>

<h1>Reservation</h1>

<form action="traiter_les_donnees_envoyees.php" method="post">
<h2>Réservez un voyage</h2>
<label for="lc">départ </label><input id="lc" name="hc" type="text"/><br/>

arrivé <input name="hn" type="text"/><br/>

date <input id="start" max="2030-12-31" min="2025-01-01" name="trip-start" type="date" value="">

heure <label for="appt"></label>
<input id="appt" max="18:00" min="09:00" name="appt" required="" type="time">
<br/>
<fieldset style="border-width: 2px 0 0">
<legend>Est-ce que vous avez une préférence ?</legend>
<input id="ja" name="r" type="radio" value="yes"/>
<label for="ja">Homme</label>
<input checked="" id="nee" name="r" type="radio" value="no"/>
<label for="nee">Femme</label>
</fieldset>
<label>
<input name="r2" type="radio" value="maybe"/>peu importe

</label>
<br/>
</input></input></form>

</body>
</html>
