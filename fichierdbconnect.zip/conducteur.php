<?php
require_once 'db.php';
$pdo = getConnection();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = $_POST;
    $columns = array_keys($data);
    $placeholders = array_map(function($col) { return ':' . $col; }, $columns);
    $sql = "INSERT INTO vehicule (" . implode(', ', $columns) . ") VALUES (" . implode(', ', $placeholders) . ")";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($data);
    echo "<p>Enregistrement réussi dans la table vehicule !</p>";
}
?>

<?php
require_once 'db.php'; // ajuster le chemin si nécessaire
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Conducteur</title>
</head>
<body>

<h1>Conducteur</h1>

<form action="traiter_les_donnees_envoyees.php" method="post">
<h2 class="text-center text-primary">Planifiez un voyage</h2>
<div class="form-group">
<label for="lc">Départ</label>
<input autocomplete="off" class="form-control" id="lc" name="hc" required="" type="text"/>
<ul class="list-group" id="suggestionsStart"></ul> <!-- Mise en page des suggestions-->
<label class="mt-3" for="arrive">Arrivée</label>
<input autocomplete="off" class="form-control" id="arrive" name="hn" required="" type="text"/> <!-- Pas de autocomplete pour éviter de proposer d'anciennes adresses -->
<ul class="list-group" id="suggestionsEnd"></ul> <!-- Mise en page des suggestions-->
<div class="col mt-3" id="map"></div>
<div class="d-flex flex-row justify-content-around">
<div class="d-flex flex-row mt-3">
<label class="input-group-text" for="start">Date</label>
<input class="form-control" id="start" max="2030-12-31" min="2025-01-01" name="trip-start" type="date" value="">
</input></div>
<div class="d-flex flex-row mt-3">
<label class="input-group-text" for="appt">Heure</label>
<input class="form-control" id="appt" max="18:00" min="09:00" name="appt" required="" type="time">
</input></div>
</div>
</div>
<fieldset class="border-top border-bottom border-secondary mt-3" style="padding: 10px;">
<legend class="text-center text-primary">Est-ce que vous avez une préférence ?</legend>
<div class="d-flex flex-column m-3">
<input class="btn-check" id="ja" name="r" type="radio" value="yes"/>
<label class="btn btn-outline-primary" for="ja">Homme</label>
<input class="btn-check" id="nee" name="r" type="radio" value="no"/>
<label class="btn btn-outline-primary" for="nee">Femme</label>
<input checked="" class="btn-check" id="whynot" name="r" type="radio" value="maybe"/>
<label class="btn btn-outline-primary" for="whynot">Peu importe</label>
</div>
</fieldset>
</form>

</body>
</html>
