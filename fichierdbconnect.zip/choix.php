<?php
require_once 'db.php';
$pdo = getConnection();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = $_POST;
    $columns = array_keys($data);
    $placeholders = array_map(function($col) { return ':' . $col; }, $columns);
    $sql = "INSERT INTO trajet (" . implode(', ', $columns) . ") VALUES (" . implode(', ', $placeholders) . ")";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($data);
    echo "<p>Enregistrement réussi dans la table trajet !</p>";
}
?>

<?php
require_once 'db.php'; // ajuster le chemin si nécessaire
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Choix</title>
</head>
<body>

<h1>Choix</h1>

<form class="mt-4" id="choiceForm" onsubmit="handleFormSubmission(event)">
<div aria-label="Choix" class="btn-group w-100" role="group">
<input autocomplete="off" checked="" class="btn-check" id="conducteur" name="travel" type="radio" value="Conducteur"/>
<label class="btn btn-outline-primary btn-size-medium w-50" for="conducteur">Conducteur</label>
<input autocomplete="off" class="btn-check" id="passager" name="travel" type="radio" value="Passager"/>
<label class="btn btn-outline-primary btn-size-medium w-50" for="passager">Passager</label>
</div>
<div class="text-center mt-3">
<button class="btn btn-outline-primary" type="submit">Confirmer</button>
</div>
</form>

</body>
</html>
