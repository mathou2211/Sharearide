<?php
// Connexion à la base
include 'db.php';
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Sharearide</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background-color: #f4f4f4; }
        h1 { color: #333; }
        section { background: #fff; padding: 15px; margin-bottom: 20px; border-radius: 8px; box-shadow: 0 0 8px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <h1>Bienvenue sur Sharearide</h1>

    <section>
        <h2>Utilisateurs</h2>
        <?php include 'utilisateur.php'; ?>
    </section>

    <section>
        <h2>Véhicules</h2>
        <?php include 'vehicule.php'; ?>
    </section>

    <section>
        <h2>Trajets</h2>
        <?php include 'trajet.php'; ?>
    </section>

    <section>
        <h2>Réservations</h2>
        <?php include 'reservation.php'; ?>
    </section>
</body>
</html>
